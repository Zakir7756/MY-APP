import 'package:flutter/material.dart';

class Homescreen extends StatefulWidget {
  const new({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {
  int selectedIndex = 0;

  final List<String> pages = [
    "HOME PAGE",
    "ABOUT PAGE",
    "SEARCH PAGE",
    "SETTING PAGE",
    "LOGOUT",
  ];

  void onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });

    print(pages[index]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ITACHI UCHIHA A LEGENDARY HERO"),
        backgroundColor: Colors.redAccent,
        centerTitle: true,
      ),

      //SIDE BAR
      drawer: Drawer(
        child: ListView(
          children: [
            // FlutterLogo(size: 100),
            ClipOval(
              child: Image.asset(
                'assets/images/1.jpg',
                width: 100,
                height: 100,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 15),
            Text("ITACHI UCHIHA", textAlign: TextAlign.center),
            // HOME
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text("Home"),
              onTap: () {
                // print("HOME PAGE");
                onItemTapped(0);
                Navigator.pop(context);
              },
            ),
            // ABOUT
            ListTile(
              leading: const Icon(Icons.info),
              title: const Text("About"),
              onTap: () {
                // print("ABOUT PAGE");
                onItemTapped(1);
                Navigator.pop(context);
              },
            ),

            // SEARCH
            ListTile(
              leading: const Icon(Icons.search),
              title: const Text("Search"),
              onTap: () {
                // print("SEARCH PAGE");
                onItemTapped(2);
                Navigator.pop(context);
              },
            ),
            // SETTING
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text("Setting"),
              onTap: () {
                // print("SETTING PAGE");
                onItemTapped(3);
                Navigator.pop(context);
              },
            ),
            // LOGOUT
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("Logout"),
              onTap: () {
                // print("LOGOUT PAGE");
                onItemTapped(4);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),

      // BODY
      body: Center(
        child: Text(
          pages[selectedIndex],
          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
      ),
      // BOTTOM NAVIGATION BAR
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        onTap: onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.redAccent,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),

          BottomNavigationBarItem(icon: Icon(Icons.info), label: "About"),

          BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),

          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Setting"),

          BottomNavigationBarItem(icon: Icon(Icons.logout), label: "Logout"),
        ],
      ),
    );
  }
}
