// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// class Aboutscreen extends StatefulWidget {
//   const new({super.key});

//   @override
//   State<Aboutscreen> createState() => _AboutscreenState();
// }

// class _AboutscreenState extends State<Aboutscreen> {
//   bool loading = false;
//   String Link = 'https://jsonplaceholder.org/users';

//   Future<void> getdata() async {
//     setState(() {
//       loading = true;
//     });
//     try {
//       final response = await http.get(Uri.parse(Link));
//       print("get Data from API=======> ${response.statusCode}");
//       print("get Data from API=======> ${response.body}");
//     } catch (e) {
//       print(e);
//     } finally {
//       setState(() {
//         loading = false;
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: loading
//             ? CircularProgressIndicator()
//             : Column(
//                 children: [
//                   ElevatedButton(onPressed: getdata, child: Text("Get Data")),
//                 ],
//               ),
//       ),
//     );
//   }
// }

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:app/MODELS/models.dart';

class HomeScreen extends StatefulWidget {
  const new({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool loding = false;
  String link = 'https://jsonplaceholder.typicode.com/posts';
  List<PostModel> posts = [];
  // Yahan 'Future<void>' aur 'async' add kiya hai
  Future<void> getdata() async {
    posts.clear();
    setState(() {
      loding = true;
    });
    try {
      final response = await http.get(Uri.parse(link));
      // print('get api data =========> ${response.statusCode}');
      // print('get api data =========> ${response.body}');

      final data = jsonDecode(response.body);
      for (var post in data) {
        PostModel newPost = PostModel(
          post['id'],
          post['userId'],
          post['title'],
          post['body'],
        );
        posts.add(newPost);
      }
    } catch (e) {
      print(e);
    } finally {
      setState(() {
        loding = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: loding
            ? CircularProgressIndicator()
            : Column(
                children: [
                  ElevatedButton(onPressed: getdata, child: Text("Get Method")),
                  Expanded(
                    child: ListView(
                      children: [
                        for (var post in posts)
                          ListTile(
                            title: Text(post.title),
                            subtitle: Text(post.body),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
