class PostModel {
  int id, userId;
  String title,body;

  PostModel(this.id, this.userId, this.body, this.title);
}
